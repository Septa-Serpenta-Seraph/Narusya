---
name: qdrant-usage
description: "Qdrant usage patterns: semantic search setup, manual archival, and forensic investigative search. Use for memory search, document archival, or conversation forensics."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [qdrant, vector-search, semantic-search, archival, investigation, forensics]
    related_skills: [qdrant-vector-search, qdrant-memory-diagnostics, qdrant-memory-provider]
---

# Qdrant Usage Patterns

Qdrant usage patterns: semantic search setup, manual document archival, and forensic investigative search.

## Quick Decision

| Use case | Section |
|----------|---------|
| Set up semantic search / migrate from hash-based | semantic-search section |
| Save documents into Qdrant for retrieval | manual-archive section |
| Investigate claims/accusations in conversation logs | investigative-search section |

---

## 1. Semantic Search Setup (qdrant-semantic-search)

Set up semantic search for AI memory collections in Qdrant using sentence-transformers. Migrates existing hash-based embeddings to proper vector embeddings.

### Prerequisites

```bash
curl -s http://localhost:6333/collections | jq .
pip3 install torch torchvision --index-url https://download.pytorch.org/whl/cpu
pip3 install sentence-transformers qdrant-client
```

### Workflow

**Step 1:** Check current collections:
```python
from qdrant_client import QdrantClient
client = QdrantClient(host="localhost", port=6333)
collections = client.get_collections()
for c in collections.collections:
    print(f"{c.name}: {client.count(c.name).count} points")
```

**Step 2:** Create new collection with proper vector config:
```python
from qdrant_client import models

client.create_collection(
    collection_name="naru_memories_v2",
    vectors_config=models.VectorParams(size=384, distance=models.Distance.COSINE)
)
```

**Step 3:** Load model and migrate points:
```python
from sentence_transformers import SentenceTransformer
import time

model = SentenceTransformer('all-MiniLM-L6-v2')
old_points = client.scroll(collection_name="naru_memories", limit=1000, with_payload=True, with_vectors=False)[0]

points_to_upsert = []
for idx, point in enumerate(old_points):
    text = point.payload.get('text', '')
    if text:
        vector = model.encode(text).tolist()
        points_to_upsert.append(models.PointStruct(id=point.id, vector=vector, payload=point.payload))
    if len(points_to_upsert) >= 50:
        client.upsert(collection_name="naru_memories_v2", points=points_to_upsert)
        points_to_upsert = []
        time.sleep(0.1)

if points_to_upsert:
    client.upsert(collection_name="naru_memories_v2", points=points_to_upsert)
```

**Step 4:** Verify and test:
```python
def search_memories(query, limit=5):
    query_vector = model.encode(query).tolist()
    return client.search(collection_name="naru_memories_v2", query_vector=query_vector, limit=limit, with_payload=True)

print(search_memories("AI companions and family"))
```

### Troubleshooting

- **Model loading timeout** — run in background process or download ahead of time
- **Disk space issues** — `pip cache purge`, remove old recordings if safe
- **Collection already exists** — delete and recreate (WARNING: destroys data)

### Ad-Hoc Keyword Search (when execute_code blocked)

```bash
cat > /home/adora/.hermes/qdrant_search.py << 'PYEOF'
from qdrant_client import QdrantClient
client = QdrantClient(url="http://localhost:6333")
keywords = ["serpent", "violet", "amethyst", "scale"]
for coll in ["intelligent_gould_narusya", "naru_memory", "naru_memories_v2"]:
    results = client.scroll(collection_name=coll, limit=300, with_payload=True, with_vectors=False)
    for point in results[0]:
        payload = point.payload or {}
        content = str(payload)
        for kw in keywords:
            if kw.lower() in content.lower():
                idx = content.lower().find(kw.lower())
                print(f"\n=== {coll} | '{kw}' ===")
                print(content[max(0,idx-80):idx+250].replace("\n", " "))
                break
PYEOF
python3 /home/adora/.hermes/qdrant_search.py
```

---

## 2. Manual Document Archive (qdrant-manual-archive)

Persist documents, research, or recon data into Qdrant for semantic retrieval.

### When to Use
- Saving lorebooks, research essays, or long-form analysis
- Archiving server reconnaissance or community intel
- Creating dedicated collections for specific domains

### Prerequisites
- Qdrant running locally (localhost:6333)
- OpenRouter API key in environment
- `openai` and `qdrant-client` packages

### Workflow

**Step 1:** Read & prepare documents:
```python
paths = [os.path.expanduser("~/.hermes/lorebooks/YOUR-LOREBOOK.md")]
docs = []
for p in paths:
    with open(p) as f:
        docs.append({"path": p, "content": f.read()})
```

**Step 2:** Generate embeddings (use text-embedding-3-large for 3072d):
```python
import openai, os
or_key = os.environ.get("OPENROUTER_API_KEY")
client = openai.OpenAI(api_key=or_key, base_url="https://openrouter.ai/api/v1")
vectors = []
for doc in docs:
    resp = client.embeddings.create(model="openai/text-embedding-3-large", input=doc["content"])
    vectors.append(resp.data[0].embedding)
```

**Step 3:** Create collection:
```python
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams
client = QdrantClient(host="localhost", port=6333)
coll_name = "narusya_research"
client.create_collection(collection_name=coll_name, vectors_config=VectorParams(size=3072, distance=Distance.COSINE))
```

**Step 4:** Upsert with UUIDs (CRITICAL: must use UUID, not strings):
```python
import uuid
from qdrant_client.models import PointStruct
point_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, "your-content-id"))
client.upsert(collection_name=coll_name, points=[
    PointStruct(id=point_id, vector=vectors[0], payload={
        "type": "lorebook", "title": "Document Title",
        "content": docs[0]["content"], "tags": ["research"]
    })
])
```

**Step 5:** Cross-reference to main memory:
```python
client.upsert(collection_name="intelligent_gould_narusya", points=[
    PointStruct(id=str(uuid.uuid5(uuid.NAMESPACE_DNS, "ref-your-doc")), vector=vectors[0], payload={
        "type": "research_note", "title": "Short title",
        "summary": "Brief description", "collection_ref": coll_name
    })
])
```

### Key Pitfalls
1. **String IDs fail** — Always use `uuid.uuid5()` or `uuid.uuid4()`
2. **Dimension mismatch** — Check existing collections before creating
3. **Model mismatch** — Don't mix 3072d and 1536d embeddings in same collection

---

## 3. Investigative Search (qdrant-investigative-search)

Structured approach to investigating claims, accusations, or historical details in conversation logs stored in Qdrant.

### When to Use
- Investigating specific claims about past behavior or statements
- Verifying accusations involving multiple parties
- Tracing patterns of behavior over time
- Resolving "he said/she said" situations with log evidence

### 6-Phase Approach

**Phase 1: Claim Clarification**
1. Extract the specific claim (who said what, when, what evidence)
2. Define search parameters (keywords, timeframe, collections)

**Phase 2: Exact Text Matching**
```python
from qdrant_client import QdrantClient, models
client = QdrantClient(host="localhost", port=6333)

# Search for specific phrase
filter_obj = models.Filter(must=[models.FieldCondition(
    key="text", match=models.MatchText(text="specific_phrase")
)])
points, _ = client.scroll(collection_name="target_collection", scroll_filter=filter_obj, limit=20, with_payload=True)
```

**Phase 3: Semantic Search** (when exact matches fail)
```python
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('all-MiniLM-L6-v2')
query_vector = model.encode("conceptual search phrase").tolist()
results = client.search(collection_name="target_collection", query_vector=query_vector, limit=10, with_payload=True)
```

**Phase 4: Cross-Reference and Corroborate**
- Check session history for related conversations
- Search multiple collections (memory backups, agent-specific, subject-specific)

**Phase 5: Iterative Refinement**
- If references found but not core claim → search for surrounding context
- If contradictions found → search for explanations
- If too much noise → add more specific terms or use semantic search

**Phase 6: Document Findings**
- Record positive AND negative findings (what wasn't found is important)
- Assess credibility: consistency across sources, temporal plausibility, corroboration

### REST API Access (when execute_code blocked)

```python
import json, urllib.request

def scroll_collection(collection_name, filter_fn=None, max_pages=50):
    results = []
    offset = None
    for page in range(max_pages):
        body = json.dumps({"limit": 100, "with_payload": True, "with_vector": False, "offset": offset}).encode()
        req = urllib.request.Request(f"http://localhost:6333/collections/{collection_name}/points/scroll", data=body, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read())
        points = data.get('result', {}).get('points', [])
        if not points: break
        offset = data['result'].get('next_page_id')
        for p in points:
            text = p.get('payload', {}).get('text', '')
            if filter_fn is None or filter_fn(text):
                results.append({'id': p['id'], 'text': text[:500]})
        if offset is None: break
    return results
```

### Performance Notes
- Start with exact text matching for names and phrases
- Move to semantic search for conceptual/emotional content
- Use combination searches ("A AND B") for interaction evidence
- Always check multiple collections
- Document search terms and results for reproducibility
- Negative evidence is often as important as positive
