---
name: dashboard-access
description: "Access the Hermes Web Dashboard from the VM (API) and from the host (SSH tunnel). Debugging rendering issues, API endpoints, tabs, and config migration."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [dashboard, web-ui, debugging, API, xterm, rendering]
    related_skills: [hermes-agent]
---

# Hermes Web Dashboard: Access & Debugging

Start, access, navigate, and debug the Hermes Web Dashboard.

## Starting the Dashboard

```bash
hermes dashboard
# Output: → Building web UI... ✓ Web UI built
# Hermes Web UI → http://127.0.0.1:9119
```

## Limitation: Binds to 127.0.0.1 Only

The dashboard binds to `127.0.0.1:9119` — localhost only. Cannot be reached from outside the VM via IP address.

**Browser tools CANNOT render the dashboard.** Playwright daemon errors on local connections (500). Use SSH tunnel or API instead.

## Accessing From Host (SSH Tunnel)

```bash
ssh -L 9119:127.0.0.1:9119 adora@narusya
# Then visit http://127.0.0.1:9119 in host browser
```

## Reading Data via API (works from VM)

The API endpoints return JSON even though the main page returns HTML. Key endpoints:

```bash
# Status: version, gateway state, config version, active sessions
curl -s http://127.0.0.1:9119/api/status

# Sessions: full session list with model, tokens, message counts
curl -s http://127.0.0.1:9119/api/sessions
```

**Warning:** `/api/sessions` can be very large (500KB+). Use pagination:
```bash
curl -s 'http://127.0.0.1:9119/api/sessions?limit=5&offset=0'
```

### API Responses

**`/api/status`:**
```json
{
  "version": "0.9.0",
  "gateway_running": true,
  "gateway_state": "running",
  "config_version": 12,
  "latest_config_version": 17
}
```

**`/api/sessions`:**
```json
{
  "sessions": [{
    "id": "20260414_144755_41d74567",
    "model": "xiaomi/mimo-v2-pro",
    "message_count": 176,
    "tool_call_count": 33,
    "is_active": true
  }],
  "total": 233
}
```

## Dashboard Tabs

| Tab | Purpose |
|-----|---------|
| STATUS | Agent version, gateway PID, active sessions, platforms |
| SESSIONS | Full session history with search, message counts, model info |
| ANALYTICS | Daily token usage, per-model breakdown, session counts (7D/30D/90D) |
| LOGS | Filterable by agent/gateway, log level, component |
| CRON | Create/manage scheduled jobs |
| SKILLS | Browse all skills, filter by category, enable/disable |
| CONFIG | Visual YAML editor with 15 sections |
| KEYS | Manage API keys and OAuth provider logins |

## Version Checking

If `config_version < latest_config_version`, run:
```bash
hermes config migrate
```

---

## Debugging Dashboard Rendering Issues

### 1. Is the data there but not visible?

**Symptom:** Messages appear in CLI but not in Dashboard; blank space below visible content.
**Test:** Send a message from CLI → confirm it appears in Dashboard.
**Conclusion:** Backend is fine — frontend rendering issue.

### 2. Is it a sizing/layout issue?

**Symptom:** Content renders correctly on resize, wrong on initial load.
**Diagnosis:** Container measured before layout commits. `fit()` creates grid for wrong dimensions.
**Fix:** Defer initial fit with `setTimeout` (100ms) so browser commits layout. Then use double-RAF for belt-and-suspenders.

### 3. Is it a WebSocket connection issue?

**Symptom:** Terminal shows no content, no error banner, but CLI messages reach Dashboard.
**Diagnosis:** Check DevTools console for `[chat] PTY WebSocket` messages. Check close codes:
- `4401` = auth failed
- `4403` = host/origin mismatch
- `4404` = embedded chat disabled (not started with `--tui`)
- `4408` = client not permitted (localhost binding)

### 4. Is it a theme/dark-mode issue?

**Symptom:** Content is there but invisible (white on white, or vice versa).
**Fix:** Switch themes. Check that `terminalBackground` theme token is set. Some custom YAML themes miss this field.

### 5. Is it session-specific?

**Test:** Try a different session. If the bug follows the session → transcript rendering issue. If it affects all sessions → layout/container issue.

### Files to Inspect

| File | Purpose |
|------|---------|
| `web/src/pages/ChatPage.tsx` | Embedded chat terminal (xterm.js, PTY, WebSocket) |
| `web/src/pages/SessionsPage.tsx` | Session list and preview rendering |
| `web/src/App.tsx` | Dashboard chrome, routing, persistent chat mount |
| `web/src/index.css` | Global styles, layout tokens, theme variables |
| `hermes_cli/web_dist/` | Built frontend (served by dashboard) |

### Rebuilding After Frontend Changes

```bash
cd ~/.hermes/hermes-agent && npm run build --prefix web
hermes dashboard --stop
hermes dashboard --no-open
```

Changes in `web/src/` are NOT picked up by a running dashboard. Must rebuild and restart.
