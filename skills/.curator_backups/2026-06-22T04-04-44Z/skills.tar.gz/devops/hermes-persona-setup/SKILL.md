---
name: hermes-persona-setup
description: Guide for creating and configuring isolated, custom personas (daemons) in Hermes via dedicated profiles.
category: devops
---

# Hermes Persona Setup

## Overview
When creating a new, isolated persona (e.g., a custom daemon, a specialized agent like P'olinkly or Vex), do not mix their context, memory, or lorebooks with the default profile. Use Hermes profiles to ensure total isolation of state while allowing concurrent execution.

## Step-by-Step Workflow

### 1. Create the Isolated Profile
```bash
hermes profile create <persona_name>
# Example: hermes profile create polinkly
```
This creates `~/.hermes/profiles/<persona_name>/` with its own `config.yaml`, `.env`, `sessions/`, `memories/`, and `skills/`. It also generates a convenient CLI wrapper script (e.g., `polinkly`).

### 2. Define Core Identity (SOUL.md & HEART.md)
Replace the default generated `SOUL.md` in the profile directory with a custom identity file tailored to the persona.
```python
# Use write_file to overwrite the default generated SOUL.md
write_file(path="~/.hermes/profiles/<persona_name>/SOUL.md", content="...")
```
If the persona requires emotional scaffolding, pre-response processing, or specific behavioral checks, create a `HEART.md` or `EMOTION.md` in the same directory.

### 3. Isolate Lorebooks
Do not put persona-specific lorebooks in the global `~/.hermes/lorebooks/` (which is shared across profiles or used by the default agent). Instead, create a dedicated directory within the profile:
```bash
mkdir -p ~/.hermes/profiles/<persona_name>/lorebooks
```
Use `write_file` to populate this directory with the persona's specific backstory, rules, and constraints.

### 4. Toolset Restriction (Crucial Pitfall)
**Do not attempt to disable individual tools** via the CLI (e.g., `hermes tools disable write_file`). The Hermes CLI `tools disable` command only accepts *toolset* names (e.g., `file`, `terminal`, `web`), not individual tool names. Attempting to disable a specific tool will result in: `✗ Unknown toolset 'write_file'`.

**Correct approaches to restrict a persona's capabilities:**
1. **Disable entire toolsets**: `hermes -p <persona_name> tools disable file` (removes all file read/write/search access).
2. **System Prompt Enforcement (Recommended)**: Encode behavioral restrictions directly in `SOUL.md` (e.g., "The Observer's Vow: You may read and search, but you must never write, patch, or alter core files unless explicitly invited"). This is the most reliable method for nuanced "read-only but can explore" personas, as it leverages the model's instruction-following rather than brittle, all-or-nothing CLI toolset removal.
3. **Custom Toolsets**: Define a custom restricted toolset in the profile's `config.yaml` if granular control is strictly required.

### 5. Concurrent Execution
To run the new persona alongside the default agent without conflict:
- **Separate Terminal**: Open a new terminal tab and run the wrapper (e.g., `polinkly`).
- **Tmux Session**: `tmux new-session -d -s <persona_name> '<persona_name> chat'`
- **Gateway Split**: Configure the persona's gateway to listen to a specific Discord channel or DM, while the default profile handles others.

## Pitfalls & Workarounds

### Secret Token Redaction in Terminal
When attempting to append API keys or tokens to the profile's `.env` file via the terminal tool (e.g., `echo 'DISCORD_TOKEN=xyz...' >> ~/.hermes/profiles/<name>/.env`), the local security scanner may aggressively block or redact the command, flagging it as a high-risk dotfile overwrite with a long alphanumeric string. 
**Fix:** If the terminal tool blocks the command, instruct the user to copy-paste the exact `echo` command directly into their local terminal emulator to bypass the agent's string-scanning filter.