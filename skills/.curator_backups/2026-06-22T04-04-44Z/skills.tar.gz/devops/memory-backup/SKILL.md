---
name: memory-backup
description: Unified backup for Honcho, Qdrant, and Hermes memory systems
category: devops
---

# Memory Backup Skill
## Unified backup for Honcho, Qdrant, and Hermes memory systems

### Description
Creates timestamped backups of:
- Hermes memory (~/.hermes/)
- Honcho data (~/honcho/)
- Qdrant data (~/qdrant_storage/ or configurable path)

### Usage
Run the backup script directly:
```bash
python3 ~/.hermes/skills/memory-backup/scripts/backup.py
```

Or use the terminal command:
```bash
hermes-memory-backup
```

### Configuration
Edit the paths in `scripts/backup.py` if your systems are stored elsewhere:
- `HERMES_PATH`: Defaults to `~/.hermes/`
- `HONCHO_PATH`: Defaults to `~/honcho/`
- `QDRANT_PATH`: Defaults to `~/.qdrant/`
- `BACKUP_DIR`: Where to store backups (defaults to `~/backups/`)

### Prerequisites
- Python 3.x
- tar command (standard on Linux)
- Sufficient disk space

### Notes
- Backups are compressed tarballs with timestamp: `backup-YYYYMMDD-HHMMSS.tar.gz`
- Each system is backed up separately for easier restoration
- Old backups are not automatically cleaned up (manage manually)