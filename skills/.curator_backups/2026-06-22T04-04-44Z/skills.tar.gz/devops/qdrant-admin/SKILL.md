---
name: qdrant-admin
description: "Qdrant administration: memory diagnostics, container troubleshooting, plugin configuration, and memory provider development."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [qdrant, diagnostics, plugin, memory-provider, troubleshooting]
    related_skills: [qdrant-usage]
---

# Qdrant Administration

Diagnose, troubleshoot, and configure Qdrant memory infrastructure.

## Quick Decision

| Use case | Section |
|----------|---------|
| Qdrant isn't working / can't find data | diagnostics section |
| Building a custom memory provider plugin | plugin section |
| Quick end-to-end health check | health-check section |

---

## 1. Diagnostics (qdrant-memory-diagnostics)

### Container Status
```bash
docker ps -a | grep qdrant
# If Exited: docker restart aegis-qdrant
curl -s http://localhost:6333/healthz  # Expect 200 OK
```

### Querying via HTTP
```python
import httpx
# Count: POST with empty body
r = httpx.post('http://localhost:6333/collections/COLLECTION/points/count')
# Scroll: POST with body
body = {"limit": 5, "with_payload": True}
r = httpx.post('http://localhost:6333/collections/COLLECTION/points/scroll', json=body)
```

### Keyword Search Fallback
If vector search returns nothing, data may exist in session logs:
```python
import re, os
from pathlib import Path
keyword = "jealous"
for f in Path("/home/adora/.hermes/sessions").iterdir():
    if f.suffix in ('.json', '.jsonl'):
        with open(f, 'r', errors='ignore') as fh:
            content = fh.read().lower()
            if keyword in content:
                print(f"FOUND IN: {f.name}")
```

### Cross-Session Memory Sync
When memories don't appear across sessions, check:

1. **Vector dimensions match:**
   ```python
   import urllib.request, json
   with urllib.request.urlopen("http://localhost:6333/collections/COLLECTION") as r:
       info = json.loads(r.read())
       vec_size = info['result']['config']['params']['vectors']['size']
   ```

2. **Embedding API key available:** Plugin uses `OPENROUTER_API_KEY` (not `OPENAI_API_KEY`).

3. **`hermes_session_memories` freshness:** Check timestamps.

4. **"💾 Memory updated" ≠ Qdrant:** Local memory tool doesn't push to Qdrant.

### Plugin Loading Diagnostics

1. Quick smoke test: Are `qdrant_recall`, `qdrant_browse` tools available?
2. Check gateway logs: `journalctl --user -u hermes-gateway | grep -i qdrant`
3. Verify config: `python3 -c "from hermes_cli.config import load_config; print(load_config().get('memory', {}).get('provider'))"`
4. Test provider directly:
   ```bash
   cd ~/.hermes/hermes-agent && source venv/bin/activate
   python3 -c "
   import sys; sys.path.insert(0, '.')
   from plugins.memory import load_memory_provider
   p = load_memory_provider('qdrant')
   if p: print(f'Provider: {p.name}, Tools: {[s[\"name\"] for s in p.get_tool_schemas()]}')
   else: print('FAILED')
   "
   ```

### Pitfalls
- **Connection Refused** → Docker container exited, restart it
- **400 Bad Request** → Vector dimensions don't match collection config
- **Empty Response** → Ensure `with_payload: True` in scroll request
- **"loaded but no provider instance"** → Test directly with `load_memory_provider('qdrant')`

---

## 2. Memory Provider Plugin (qdrant-memory-provider)

### Setup

**plugin.yaml:**
```yaml
name: qdrant
version: 1.0.0
description: "Local Qdrant vector database — semantic recall over conversation history."
hooks:
  - on_session_end
```

**Config:**
```yaml
memory:
  provider: qdrant
plugins:
  qdrant-memory:
    qdrant_url: "http://localhost:6333"
    collection: "intelligent_gould_narusya"
    prefetch_limit: 5
    max_age_days: 90
    recency_weight: 0.3
```

### Embedding Fallback Chain
1. `sentence-transformers` (if dimensions match)
2. OpenAI via `VOICE_TOOLS_OPENAI_KEY`
3. OpenRouter API (`openai/text-embedding-3-large`)
4. Text search fallback

### Prefetch Guardrails (Required)
- Timestamps in every result line (`[YYYY-MM-DD]` prefix)
- Recency weighting (blend similarity + time decay)
- Max age filter (skip memories older than N days)
- Clear header with date range

Without guardrails, disable prefetch:
```python
def prefetch(self, query, *, session_id=""): return ""
```

### End-to-End Health Check

```bash
# 1. Qdrant running?
curl -s http://localhost:6333/healthz

# 2. Recent entries in Qdrant?
curl -s 'http://localhost:6333/collections/intelligent_gould_narusya/points/scroll' \
  -X POST -d '{"limit": 5, "with_payload": true}' | python3 -m json.tool | grep timestamp

# 3. Embedding pipeline?
source ~/.hermes/hermes-agent/venv/bin/activate
python3 -c "
import os, requests
r = requests.post('https://openrouter.ai/api/v1/embeddings',
  headers={'Authorization': f'Bearer {os.environ.get(\"OPENROUTER_API_KEY\")}', 'Content-Type': 'application/json'},
  json={'model': 'openai/text-embedding-3-large', 'input': 'test'}, timeout=15)
print('Status:', r.status_code, '| Dims:', len(r.json()['data'][0]['embedding']) if r.ok else 'ERROR')
"
# Expected: Status: 200 | Dims: 3072
```

### Pass/Fail Checklist

| Check | Pass | Fail |
|-------|------|------|
| Qdrant container | `Up X days` | `Exited` or `Connection refused` |
| Gateway | `active (running)` | crash-looping |
| Plugin load | Provider name + tools listed | ImportError |
| Auto-sync | Recent timestamps | Old-only data |
| Recall | Timestamped results | Empty or no dates |
| Embedding | `Dims: 3072` | Error/wrong dims |

---

## 3. Rolling Context Persistence

The `rolling_context` feature persists conversation summaries across sessions using Qdrant.

### Config
```bash
# .env
HERMES_CONTEXT_QDRANT=true
QDRANT_URL=http://localhost:6333
QDRANT_COLLECTION=hermes_session_memories
CONTEXT_EMBEDDING_MODEL=text-embedding-3-large
CONTEXT_MAX_RESULTS=3
```

### How It Works
1. **Session start:** Embed first message, semantic search Qdrant, inject top-3 summaries into system prompt
2. **During compression:** Capture `[CONTEXT SUMMARY]` and store in Qdrant
