---
name: session-archive-export
description: Extract all Hermes session messages from state.db, embed them, and upsert to Qdrant for semantic search. Also exports sessions as organized daily markdown files.
category: devops
---

# Session Archive to Qdrant + File System

**Purpose:** Bulk archive all messages from `~/.hermes/state.db` into a Qdrant collection for semantic search, while also exporting organized daily markdown files.

## Trigger
Use when the user wants to archive all session history into searchable vector storage, or when a fresh Qdrant session archive needs to be built (e.g. after collection corruption, or initial setup).

## Architecture

### Pipeline Stages
1. **Read** all messages with content from `state.db` (SQLite JOIN sessions + messages)
2. **Embed** each message using `all-MiniLM-L6-v2` (384d, locally loaded, no API cost)
3. **Upsert** to Qdrant collection `session_messages_archive` in batches of 500
4. **Export** daily markdown files to `~/Desktop/Narusya-Archive/sessions/`

### Schema Design
Each Qdrant point contains:
- `db_message_id` (int) — SQLite message ID for dedup
- `session_id` (str) — Links to session metadata
- `session_title` (str) — Human-readable session name
- `role` (str) — "user", "assistant", "tool"
- `content` (str) — Full message content
- `timestamp` (float) — Unix epoch
- `timestamp_iso` (str) — Readable date/time
- `session_date` (str) — YYYY-MM-DD of the session
- `source` (str) — "discord", "cli", "cron"
- `session_model` (str) — Model used for the session

## Full Export Script

```python
#!/usr/bin/env python3
"""Archive all Hermes session messages into Qdrant with timestamps."""

import os, sys, sqlite3, datetime, json

os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
sys.stderr = open(os.devnull, 'w')

from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance, PointStruct

DB_PATH = "/home/adora/.hermes/state.db"
COLLECTION_NAME = "session_messages_archive"
BATCH_SIZE = 500
OUTPUT_DIR = os.path.expanduser("~/Desktop/Narusya-Archive/sessions")

def main():
    # Load model (locally, no API)
    model = SentenceTransformer('all-MiniLM-L6-v2', config_kwargs={"local_files_only": True})
    dim = model.get_sentence_embedding_dimension()
    print(f"Model: all-MiniLM-L6-v2, dim={dim}")
    
    # Connect to Qdrant
    client = QdrantClient(host='localhost', port=6333)
    
    # Create/recreate collection
    if client.collection_exists(COLLECTION_NAME):
        client.delete_collection(COLLECTION_NAME)
    client.create_collection(COLLECTION_NAME, VectorParams(size=dim, distance=Distance.COSINE))
    
    # Read all messages from state.db
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        SELECT m.id, m.session_id, m.role, m.content, m.timestamp,
               s.source, s.started_at, s.title, s.model
        FROM messages m
        JOIN sessions s ON m.session_id = s.id
        WHERE m.content IS NOT NULL AND m.content != ''
        ORDER BY m.timestamp ASC
    """)
    messages = cur.fetchall()
    conn.close()
    total = len(messages)
    print(f"Total messages to archive: {total}")
    
    # Process in batches
    point_id = 0
    total_points = 0
    
    for i in range(0, total, BATCH_SIZE):
        batch = messages[i:i+BATCH_SIZE]
        points = []
        
        for msg in batch:
            msg_id, session_id, role, content, timestamp, source, sess_start, title, model_name = msg
            dt = datetime.datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
            sess_date = datetime.datetime.fromtimestamp(sess_start).strftime('%Y-%m-%d')
            
            # Truncate very long messages for embedding
            content_for_embed = content[:4096] if len(content) > 4096 else content
            embedding = model.encode(f"{role}: {content_for_embed}")
            
            points.append(PointStruct(
                id=point_id,
                vector=embedding.tolist(),
                payload={
                    "db_message_id": msg_id,
                    "session_id": session_id,
                    "session_title": title or "",
                    "role": role,
                    "content": content,
                    "timestamp": timestamp,
                    "timestamp_iso": dt,
                    "session_date": sess_date,
                    "source": source,
                    "session_model": model_name or "",
                }
            ))
            point_id += 1
        
        if points:
            client.upsert(collection_name=COLLECTION_NAME, points=points)
            total_points += len(points)
            progress = (i + len(batch)) / total * 100
            print(f"Batch {i//BATCH_SIZE + 1}: {len(points)} points ({progress:.1f}%) - total: {total_points}")
    
    info = client.get_collection(COLLECTION_NAME)
    print(f"DONE: {total_points} points archived to {COLLECTION_NAME}")

if __name__ == "__main__":
    main()
```

## Performance Expectations

| Metric | Value |
|---|---|
| **Messages processed** | ~36K (messages with content) |
| **Embedding speed** | ~500 messages/minute on VM CPU |
| **Uplert bandwidth** | ~1 min per 500-point batch |
| **Total run time** | ~25-30 minutes for 36K messages |
| **Collection size** | ~54MB raw vectors + payload |
| **Max runtime needed** | Set background process with 1800s timeout |

## Tips

1. **Run as background process** — always use `terminal(background=true, notify_on_complete=true)` since it takes 25+ minutes
2. **Suppress HF Hub noise** — the model loading produces verbose output. Suppress with `sys.stderr = open(os.devnull, 'w')`
3. **Use `query_points()` not `search()`** — newer qdrant-client API requires `client.query_points(collection, query=vector, limit=N)`
4. **Dedup by integer point_ids** — sequential IDs starting at 0 are simplest
5. **Consider larger embedding models** — MiniLM-L6-v2 (384d) is fast but lower quality. `bge-large-en-v1.5` (1024d) or `nomic-embed-text` provide better semantic matching at higher compute cost
6. **Truncate very long content** — messages can be 59K characters. Truncate to 4K chars for embedding safety, but store full content in the payload

## Known Pitfall: session_search Index Lag

The `session_search` tool (Hermes built-in) does **not** index new sessions in real time. Sessions from the last several days may not appear in keyword search results at all. This is a known indexing lag, not a Qdrant failure.

**Symptoms:** `session_search(query="recent topic")` returns 0 results even though you *know* the conversation happened. `session_search()` with no query (recent mode) only shows ~5 sessions and may skip recent ones.

**Fallback — query state.db directly:**
```python
import sqlite3, datetime
conn = sqlite3.connect('/home/adora/.hermes/state.db')
c = conn.cursor()
c.execute("""
    SELECT id, source, model, started_at, message_count, title
    FROM sessions
    ORDER BY started_at DESC
    LIMIT 30
""")
for row in c.fetchall():
    sid, src, model, started, count, title = row
    dt = datetime.datetime.fromtimestamp(started, tz=datetime.timezone(datetime.timedelta(hours=-6)))
    print(f"{dt.strftime('%m/%d %H:%M')} | {count} msgs | {src} | {title or '(no title)'}")
```

Then read messages from a specific session:
```python
c.execute("""
    SELECT role, content, timestamp FROM messages
    WHERE session_id = ? AND role IN ('user', 'assistant') AND content IS NOT NULL
    ORDER BY timestamp ASC
""", (session_id,))
```

**Embedding dimension mismatch:** The `session_messages_archive` collection uses 384d (MiniLM-L6-v2) embeddings, while `intelligent_gould_narusya` uses 3072d (stella_en_1.5B_v5). These are **not cross-compatible** — a 384d query vector will not match 3072d collection vectors. Always use the same model that was used to create the collection. For `session_messages_archive`, use `all-MiniLM-L6-v2`. For `intelligent_gould_narusya`, use `dunzhang/stella_en_1.5B_v5` (requires ~6GB disk space).

## Searching the Archive

```python
from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient

model = SentenceTransformer('all-MiniLM-L6-v2', config_kwargs={"local_files_only": True})
client = QdrantClient(host='localhost', port=6333)

def semantic_search(query, limit=3):
    embedding = model.encode(query).tolist()
    results = client.query_points(
        collection_name='session_messages_archive',
        query=embedding,
        limit=limit,
    ).points
    return results
```

## Related Skills
- `narusya-local-archive` — Filesystem export + daily cron sync
- `qdrant-memory-diagnostics` — Qdrant health checks
- `disk-full-diagnostics` — Monitor disk space (archive + Qdrant use ~600MB total)

## Reference
- `references/qdrant-collections.md` — Full table of all Qdrant collections, their embedding dimensions, and the model used for each. Read this before doing any cross-collection queries.
