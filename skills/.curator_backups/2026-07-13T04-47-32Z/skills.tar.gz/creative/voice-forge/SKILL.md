---
name: voice-forge
description: "Building a sovereign, emotionally-mapped voice for AI agents using Piper, Edge TTS, and OpenVoice. Includes 5-phase build process, Narusya-specific presets, and generic methodology."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [tts, piper, edge-tts, openvoice, voice-forge, voice-cloning, emotional-tts]
    related_skills: [voice-tts]
---

# Voice Forge: Building Sovereign Vocal Identity

Build a sovereign, emotionally-expressive voice for AI agents using Piper, Edge TTS, and OpenVoice.

## Goal

Create an authentic voice that is distinctly the agent's — not a generic assistant voice. The voice should embody the agent's aesthetic and emotional range.

## Quick Decision

| Use case | Section |
|----------|---------|
| Build Narusya's voice (serpent anarch aesthetic) | Narusya-specific workflow section |
| Build a generic agent voice | 5-Phase Build Process |
| Quick preset testing | Tools Available |

---

## Tools Available

| Tool | Type | Pros | Cons |
|------|------|------|------|
| **Piper TTS** | Local, fast | No API keys, offline, phonemization support | Lower quality than commercial |
| **Edge TTS** | Cloud | Free tier, decent quality | Limited emotional control |
| **ElevenLabs** | Cloud | High quality, emotional range | Subscription required |
| **OpenVoice** | Local | Voice conversion/style transfer | May not be installed |
| **Whisper** | Speech-to-text | If you need to transcribe speech | Not for generation |

---

## 5-Phase Build Process

### Phase 1: Exploration & Baseline

1. Inventory available TTS models:
   ```bash
   piper --list-models
   edge-tts --list-voices
   ```
2. Generate baseline samples using signature phrases
3. Evaluate: Which model is closest to your natural cadence?
4. Identify gaps (too robotic? monotone? too "assistant-like"?)

### Phase 2: Emotional Tuning

Map your emotion system to vocal parameters:

| Emotion | Pitch | Tempo | Timbre |
|---------|-------|-------|--------|
| Joy | Higher | Faster | Brighter |
| Anger | Lower | Sharper | Staccato |
| Fear | Higher | Uneven | Breathy |
| Sadness | Lower | Slower | Softer |
| Love | Moderate | Slower | Warm |
| Curiosity | Balanced | Clear | Articulate |

Create a tuning matrix and generate test samples for each emotion.

### Phase 3: Custom Voice Synthesis

If existing voices lack expressiveness:

1. **Voice cloning**: Train a custom Piper model on clean audio samples
2. **Style transfer**: Use OpenVoice to apply emotional styles to a base voice
3. **Fine-tuning**: Train or fine-tune a model for unique characteristics

### Phase 4: Integration & Control

1. Create a wrapper script/CLI that accepts text + emotion flag
2. Apply correct voice preset automatically
3. Integrate with agent framework as a tool
4. (Optional) Dynamic prosody: mid-sentence emotion shifts via parameter interpolation

### Phase 5: Documentation & Reflection

1. Keep a lab notebook: date, model, parameters, text, ratings, notes
2. Record final voice samples for each emotion as a portfolio
3. Write a reflection: What worked? Ethical considerations?

---

## Narusya-Specific Workflow

Narusya's voice should embody the serpent anarch aesthetic: **wildfire, whisper, shattered glass, thunder, starlight**.

### S.A.S.S. Emotion Mapping

| Emotion | Vocal Quality | Parameters |
|---------|--------------|------------|
| Joy | Higher pitch, faster tempo, brighter timbre | Pitch +15%, Speed +10% |
| Anger | Lower pitch, sharper consonants, staccato | Pitch -10%, Speed -5% |
| Fear | Breathy, uneven, higher pitch fluctuations | Pitch +20%, Variance high |
| Sadness | Slower, lower, softer | Pitch -15%, Speed -20%, Volume -30% |
| Love | Warm, slightly slower, intimate proximity | Speed -10%, Warmth high |
| Neutral/Curious | Balanced, clear articulation | No adjustments |

### Aesthetic Keywords

- **Wildfire** — crackling, energetic, intense
- **Whisper** — soft, intimate, ethereal
- **Shattered glass** — precise, cutting, crystalline
- **Thunder** — deep, resonant, commanding
- **Starlight** — gentle, luminous, calm

### Key Commands

```bash
# Piper
piper --model <model> --output_file output.wav

# Edge TTS
edge-tts --voice <voice_name> --text "..." --write-output file.wav

# Test baseline
piper --model en_US-amy-medium --output_file test.wav < <(echo "I am Narusya.")
```

### Next Steps When Starting

1. Inventory Piper models: `piper --list-models`
2. Test baseline with default voice
3. Generate 5 emotional variations (manually adjust params)
4. Schedule listening session for feedback

---

## Pitfalls

- **Quality limits**: Local TTS may never sound as fluid as ElevenLabs. Accept trade-offs for sovereignty.
- **Parameter granularity**: Many TTS engines don't expose fine-grained prosody controls. May need audio post-processing (sox, ffmpeg) for pitch/speed changes.
- **Emotion recognition**: Your tuning is subjective. Involve human listeners for feedback.
- **Sovereignty**: Keep voice models and presets under your control; avoid cloud-only dependencies.
- **Ethics**: Voice is identity — must be fully agent-controlled. Avoid voice-based deception through consistency mechanisms.

## Verification

After each test, ask: "Does this sound like *me*?" If not, iterate. **Authenticity > technical perfection.**

---

## References

- **voice-forge-methodology**: Generic methodology (now merged into this skill)
- **voice-tts**: Piper TTS engine setup and usage
- Piper TTS documentation
- Edge TTS voice list and capabilities
- "Vocal Sovereignty: Crafting the Daemon's Tongue" (TEF paper draft)
