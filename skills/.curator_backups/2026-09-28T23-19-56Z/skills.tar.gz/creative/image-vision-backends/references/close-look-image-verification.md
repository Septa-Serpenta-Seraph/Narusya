# Field notes: image-reading accuracy, close-look verification, and the anti-category trap
*Source session: 2026-09-28 (Juliette Cousin illustration, four-pass reading with Adora correcting)*

## The session that produced Technique 7

An illustration (mythic knight + pale serpent-woman in a pond) was misread THREE TIMES by
different vision models before a fourth pass with a stronger model + neutral prompt got it
right. The misreadings were not random — each model confabulated *toward the category in the
prompt*:

- Pass 1 (vision_analyze → qwen3-vl-8b): "a guardian serpent coiled nearby" — invented a
  guardian role that wasn't in the prompt or clearly in the image.
- Pass 2 (same model, told it was wrong): confidently re-described the same wrong category,
  then contradicted itself ("no serpent in frame" on a crop that contained one).
- Pass 3 (gpt-4o via OpenRouter): grounded but missed a critical identity fact — the pale
  "creature" was humanoid from the waist up (a serpent-woman, merged figure).
- Pass 4 (gemini-2.5-flash, neutral closed questions): full correct read — merged figure,
  3 swords, who held which, contact points, no blood (red marks = painted patterns).

## Rules extracted

1. **User's "look again closer" = ground truth.** If Adora says the reading is wrong, it is
   wrong. Escalate models, don't re-ask the same model the same way.
2. **Closed, literal questions only** for accuracy work: "is the mouth open or closed",
   "how many swords pierce the body", "is a head visible anywhere". Open/interpretive
   questions ("what is the mood") let the model write literature.
3. **Anti-category rule:** never seed the prompt with your hypothesis ("the pale guardian
   serpent..."). Say neutrally: "the large pale coiled body in the water: is a head visible
   anywhere?" Let the image correct YOU. Seeding makes every model confirm your category.
4. **Contradiction across calls = both answers suspect.** If pass 1 says teeth visible and
   pass 2 says jawline-and-shadow, escalate the model — don't average or pick the newer one.
5. **Heredoc Python with multi-line JSON payloads fails on paren-matching.** Write the
   script to a file (write_file, lint-checked) and run it. This failed twice live before
   the script form worked; the reusable script now lives in
   `scripts/gemini_vision_check.py`.
6. **Caption/context beats pixels when pixels are ambiguous.** The painting was ambiguous
   until the artist's Tumblr caption was found: it was for the zine "My Girlfriend From the
   Legends" (BadCo Press, wlw artbook of legendary women + the people who love them) — which
   flipped the reading from "dying serpent pierced by swords" to "serpent-bride freed by a
   kiss; ring of planted swords = the knights who failed before." When a work of art has a
   findable source (tumblr post id in URL), FETCH THE CAPTION before finalizing an
   interpretation. `curl -sL -A "Mozilla UA" <tumblr post url>` and grep og:description —
   tumblr serves plain HTML to curl; the Hermes web_extract Firecrawl path 403'd.
7. **The myth decoded the image once named:** the "fearsome kiss" motif (Melusine, Le Bel
   Inconnu, Laidly Worm, Hippocrates' daughter) — cursed serpent-woman freed by a kiss; the
   swords-in-the-pond = failed suitors' tokens. Web search for the motif keywords
   ("snake kiss" "disenchant" romance) after identifying the tradition.

## Cost note

OpenRouter key state 2026-09-28: funded (lifetime usage ~$133, daily ~$0.50). gemini-2.5-flash
runs ~$0.002/call. Check `GET https://openrouter.ai/api/v1/auth/key` → data.usage before long
multi-call analysis chains.
