---
name: hosted-game-servers
description: "Administer panel-hosted game servers via Pterodactyl API."
tags: [gaming, hosting, pterodactyl, minecraft, pebblehost, server-setup]
platforms: [linux]
---

# Hosted Game Server Panel Administration

## When to use
- User bought or wants a game server on a Pterodactyl-based host (PebbleHost, BisectHosting, etc.) and needs it built/configured
- Managing a hosted server: power, files, plugins, whitelist, backups, version upgrades
- Choosing a hosting provider/plan for a community game server
- Panel reports a state that doesn't match reality (says running, port closed)

This skill complements `minecraft-modpack-server` (self-hosted modded servers) — use that one for local/VM installs, this one for panel-hosted. Note: `minecraft-modpack-server`'s Java table predates the 2026 versioning change — this skill's `minecraft-versions-2026.md` reference is the current authority on versions and Java requirements.

## High-level flow
1. **Provider choice:** For friends/community servers (6-15 players, vanilla+plugins): PebbleHost Budget 6GB (~$6/mo) is the value pick; subuser panel access is the community feature to want. DatHost (hourly billing) for zero-commitment trials. Skip hosts' 'support/setup' add-ons when the agent can configure everything itself.
2. **Get API access:** user creates a `ptlc_` client key at `panel.<host>/account/api` (direct URL — mobile menus hide it). Store in `~/.hermes/secrets/`, never in chat.
3. **Drive the panel over HTTPS** — no browser needed. See `references/pterodactyl-client-api.md` for the full endpoint cookbook (auth, power, files, uploads, console, backups, startup variables).
4. **Version right:** 2026 Minecraft uses year-based versioning (26.x) and **requires Java 25**. See `references/minecraft-versions-2026.md`.
5. **Plugins via Modrinth API**, whitelist with real usernames verified against Mojang, automated backups from the agent's own cron (panel schedule actions are limited). See `references/plugin-install-recipe.md` for the end-to-end Modrinth→panel install recipe (worked example: TorchHeadLight, 2026-09-25).
6. **Verify externally:** panel 'running' state ≠ port actually open; check with TCP connect or `api.mcsrvstat.us`.

## References
- `references/pterodactyl-client-api.md` — full endpoint cookbook: auth, power, file read/write, uploads, console commands, backups, startup variables, and request quirks (User-Agent requirement, URL-encoded file paths, PUT vs POST)
- `references/minecraft-versions-2026.md` — the 26.x versioning scheme, Java 25 requirement, Paper download API, world-migration notes, plugin compatibility checks, username vs display-name pitfall
- `references/fawe-coreprotect-troubleshooting.md` — FAWE `CoreProtectLogger` noise during WorldEdit use: diagnosis chain (rotated .log.gz logs), root cause (`extent.debug: true` default), config fix + why NOT to disable CoreProtect's `worldedit: true`
- `references/rail-speed-plugins.md` — minecart/powered-rail speed plugin landscape on Paper 26.2: no native gamerule (probed live), CartSpeed vs hsrails vs dead ends, ~4x physics ceiling, staged-not-installed status

## Datapack install (distinct from plugins — zip goes to /world/datapacks)
Datapacks are NOT plugins: download the zip, upload to panel root, then rename/move it into `world/datapacks/` (Pterodactyl rename API handles dir-creation). Server auto-loads new datapack files **on next boot** — verify via console `datapack list`, expect `[file/<name>.zip (world)]` among enabled. Verified live 2026-09-25: 'All The Music 1.7' OST-discs datapack (917+ music discs, Modrinth `minecraft-ost-music-discs`, 1.2MB zip) loaded automatically on restart with zero config; its optional ~2GB resource pack is a separate Google-Drive download (skippable). Check Modrinth `game_versions` includes the server version AND the zip's `pack.mcmeta` `min_format` fits before uploading.

## Verified plugin pool (2026-09-25, SFCA/Paper 26.2)
- **FAWE (FastAsyncWorldEdit)** (`fastasyncworldedit`) — terraform/world-edit; Paper 2.15.4 build for 26.2, 14.9MB. Boot-verified: `[FastAsyncWorldEdit] Enabling` + `CoreProtect logging successfully initialized` (WE edits become rollbackable). Commands `//`-prefixed (`//wand`, `//set`, `//copy`, `//undo`), Op-only by default.
- **TorchHeadLight 1.1.0** (`torchheadlight`, 13KB) — hold a torch, get dynamic light around you; server-side light data, works for everyone with zero client mods. Lists 26.1.x but runs fine on 26.2 (boot-verified 9/25). Enables with default `height=2.0`.
- **CartSpeed 1.0** (`cartspeed`, 11KB) — minecart speed multipliers: `/cartspeed global <x>`, `/cartspeed nearest <x>`, `/cartspeed reload`; Op-only. 26.2-listed. **Boot-verified 2026-09-26** (loaded during FAWE restart; global multiplier set to 1.5 from console, log line `Global minecart speed multiplier set to 1.5`). Author warns multipliers much above ~2x glitch (Minecraft physics hard ceiling ~4x: more adds momentum, not top speed). See `references/rail-speed-plugins.md` for the full option landscape.

## Common in-game ops (verified live 2026-09-24, SFCA/PebbleHost)
All via POST `/servers/{id}/command` with JSON `{"command": "..."}`; read effect from `/logs/latest.log` contents.
- **Whitelist**: `whitelist add <Name>` / `remove` / `list` / `off` — verify adds in latest.log after a few seconds; after `whitelist off`, confirm with log line `Whitelist is now turned off`
- **Ops**: `op <Name>` — verify in `ops.json` (expect `level: 4`)
- **Seed**: send `seed` command, then grep latest.log for `Seed: [...]` — don't try to parse NBT from level.dat (on 26.x server layouts the root level.dat is a small overlay without WorldGenSettings; NBT parsing is a dead end)
- **Spawn**: player runs `/setworldspawn` (world spawn, everyone) vs `/spawnpoint` (personal respawn); agent-side spawn writes aren't needed — the player command is precise
- **GriefPrevention trust ladder**: `/trust` (full build), `/containertrust` (chests/doors only), `/accesstrust` (doors/buttons only), `/trustlist`, `/untrust` — applies to the claim the player is standing in
- **EssentialsX multi-homes**: `/sethome <name>` + `/home <name>` for fast travel between build sites
- Username verification: Mojang lookup `https://api.minecraftservices.com/minecraft/profile/lookup/name/<Name>` returns `{id, name}` — do this for EVERY name before whitelisting (catches typos like `krob050`→`Krob`)

## Pitfalls (summary — details in references)
- Panel may claim 'running' while the game port refuses connections — restart to re-bind; always verify from outside
- The container can regenerate `server.properties` on restart: custom MOTD lost, and version upgrades can silently reset `white-list=false` — re-check security-relevant props after any change
- Budget plans cap manual backups (Pebble: 2) and slot deletion can silently fail — plan around the cap
- Microsoft display name ≠ Java username; verify via Mojang's lookup API before whitelisting
- Pterodactyl file **download** endpoint uses `file_path=` param (not `file=`; that belongs to the contents-read endpoint) — 422 'The file path field is required' means you used the wrong param name
- Download response returns `attributes.url` (a signed URL) — fetch that with a browser User-Agent to get the bytes
- If a whitelisted name doesn't exist on Mojang, check near-variants (`Krob` vs `krob050`) — real users often type a number their actual handle doesn't have
- `/startup` returns `{object: list, data: [...]}` directly (egg_variable entries, each `attributes.env_variable` / `attributes.server_value`) — it has NO `attributes` wrapper; code written for `/` and `/servers/{id}` shapes throws KeyError there
- Modrinth search `facets` param is a JSON array-of-arrays (e.g. `[["categories:bukkit"],["project_type:plugin"]]`) URL-encoded into the query — a bare `categories:plugin` bracket string returns HTTP 400
- Agent-script actions on the panel (plugin install with server restart, backups) may sit pending approval in foreground sessions — stage everything, present the plan (plugin, version, restart caveat) and wait for explicit user go rather than retrying the blocked command
- A plugin may not list the newest MC version (e.g. supports 26.1.x, server runs 26.2) — plugins usually survive a point release; install, then judge from latest.log enable lines, not from the version list alone
- FAWE noise mentioning `net.coreprotect.worldedit.CoreProtectLogger` on `//set` = FAWE's default `extent.debug: true` complaining about CoreProtect's hook extent — edits and logging are fine; set `extent.debug: false` in FAWE config.yml, restart. Do NOT disable CoreProtect's `worldedit: true` to silence it (kills WE rollback logging). See `references/fawe-coreprotect-troubleshooting.md`
- Old console sessions rotate to `/logs/YYYY-MM-DD-N.log.gz`: fetch via the download endpoint (`file_path=` param, signed URL, browser UA) and `gzip.decompress` in Python — latest.log only holds the current boot; in-game plugin warnings live in the rotated log for when they happened
- Whitelist flow when Mojang 404s every case/spelling variant: stop guessing, ask the user to copy the exact username (title-screen or pause menu shows it) — a corrected name then verifies instantly (worked: 'Likeabucketof' dead → 'RustyToasterOven' real)
- **Staged ≠ loaded:** a jar uploaded to /plugins is completely inert until the next server boot. When the user says 'don't restart yet' (mid-build day — they did, 9/26), stage the upload, verify it landed in the dir listing, and let the next natural restart pick it up; never bounce the server without an explicit OK, and say what the restart costs (~20s blip, boots online players)
- Native capability probe: test for a vanilla/Paper gamerule by sending `gamerule <name>` via console, sleeping ~5s, and reading latest.log — `Unknown or incomplete command` means the rule doesn't exist on that build (e.g. NO minecart-speed gamerule exists on Paper 26.2 despite hsrails' README mentioning `minecartMaxSpeed` — that's for the optional Improved Minecarts experiment only)
- Modrinth search may return nothing for a multi-word query that plainly has hits ('powered rail speed' → 0): retry with a single broader keyword ('rail', 'minecart speed') — multi-word AND-matching is strict
