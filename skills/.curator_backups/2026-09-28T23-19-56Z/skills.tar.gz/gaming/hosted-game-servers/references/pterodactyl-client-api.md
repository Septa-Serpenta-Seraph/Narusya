# Pterodactyl Client API Cookbook (PebbleHost-proven)

All requests to `https://panel.<host>/api/client`. Headers:
```
Authorization: Bearer ptlc_...
Accept: Application/vnd.pterodactyl.v1+json
Content-Type: application/json
User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36
```
**The User-Agent header is mandatory** — without a browser-like UA, Cloudflare returns HTML 403 pages instead of JSON.

Helper pattern: a small `ptero.py` on the agent machine reading the key from the secrets file (key, SID, headers as module constants; an `api(path, method, body)` wrapper that returns `(status, parsed_or_raw)` — parse JSON but fall back to raw text for non-JSON responses like file contents).

## Endpoints
- `GET /` — list servers. Each entry: `attributes.identifier` (8-char server ID used everywhere), `name`, `limits`, `sftp_details`, `feature_limits` (backup slot count!).
- `GET /servers/{id}/resources` — state (running/offline), memory/cpu. State here is the process state, NOT network reachability.
- `POST /servers/{id}/power` — body `{"signal": "start|stop|restart|kill"}` → 204. Restart after config/plugin changes.
- `GET /servers/{id}/files/list?directory=/plugins` — directory listing.
- `GET /servers/{id}/files/contents?file=%2Fserver.properties` — raw file text. Paths are URL-encoded (`%2F` for leading slash).
- `POST /servers/{id}/files/write?file=%2Fserver.properties` — **raw text body, not JSON-wrapped** → 204. After writing, read the file back to verify — one session saw the write API mangle the whole file into a quoted escaped single-line blob (only recovered by re-parsing and rewriting).
- `GET /servers/{id}/files/upload` → signed URL. Append `&directory=/plugins` (or `?directory=/`), then POST multipart with field name `files`. Large jars (60MB) work fine.
- `POST /servers/{id}/files/delete` — body `{"root": "/plugins", "files": ["old.jar"]}`.
- `POST /servers/{id}/command` — body `{"command": "whitelist add Name"}` → 204. Console only; the response lands in `logs/latest.log`, so sleep ~6-10s then read the log.
- `GET /servers/{id}/files/contents?file=%2Fwhitelist.json` — verify whitelist entries (name+uuid).
- `POST /servers/{id}/backups` — start a backup. `GET /servers/{id}/backups` — list (check `is_successful`, `bytes`). **Budget plans cap manual backups (Pebble = 2).** `DELETE /servers/{id}/backups/{backup_id}` returns 204 but the slot may stay occupied — don't fight it.
- `GET /servers/{id}/startup` — list egg variables (JARFILE, LOADER_JAVAVERSION, LOADER_AUTOREBOOT...).
- `PUT /servers/{id}/startup/variable` — body `{"key": "JARFILE", "value": "paper-26.2-129.jar"}` (POST is 405 — it's PUT).
- `GET /servers/{id}/network/allocations` — the public IP:port.
- `GET /servers/{id}/files/contents?file=%2Flogs%2Flatest.log` — boot log; look for 'Done (Xs)!', plugin enable lines, stack traces. Rotated logs are .gz under `/logs`.

## Console-log diagnostics
- `whitelist add <name>` on a nonexistent username logs `That player does not exist` but returns 204 — always check the log + whitelist.json.
- Plugin 'enabled' ≠ healthy: EssentialsX on an unsupported server version logs an ERROR 'unsupported server version' but still fully functions — judge by subsequent INFO lines, not the ERROR alone.

## External verification (do not trust panel state alone)
- TCP: `bash -c 'echo > /dev/tcp/<ip>/<port>'` — connect/refused in one line.
- Status ping: `https://api.mcsrvstat.us/3/<ip>:<port>` — online, version, MOTD, players (cache ~5 min).
- A server wedged after a backup + restart sequence can show 'running' in the panel while refusing connections — a full restart re-binds the port.

## Automated backups pattern
Panel scheduled-task 'backup' is NOT in the valid action enum (only command/power). Instead run a cron on the agent's own machine: script does (1) resources check → start if stopped, (2) `save-all flush` console command, (3) POST backups, (4) sleep 60, GET backups, report name/size/is_successful. Deliver results to a home channel via cron job.
